# Zeabur Notes

Discover project/environment/services/build/variables/ports/health/volumes before mutation. Prefer controlled GitHub source deployment. Docker Hub is not required by this profile.
