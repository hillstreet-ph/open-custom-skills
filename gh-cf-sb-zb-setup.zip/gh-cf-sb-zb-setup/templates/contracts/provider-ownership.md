# Provider Ownership
GitHub: REQUIRED — source/fork/CI/release
Supabase: REQUIRED — DB/Auth/RLS/Storage/backend data
Zeabur: REQUIRED — runtime/services/workers/persistence
Cloudflare: REQUIRED — DNS/TLS/proxy/WAF/edge
Docker Hub: NOT_REQUIRED
Railway: NOT_REQUIRED
