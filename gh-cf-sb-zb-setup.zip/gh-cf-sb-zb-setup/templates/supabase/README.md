# Supabase Notes

Discover actual schema/Auth/RLS/Storage/backups before generating changes. Never invent project IDs or secret values.
