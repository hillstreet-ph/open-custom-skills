# GH-CF-SB-ZB E2E REPORT

## Overall
STATUS:
MODE:
APPLICATION:
VERSION:
GIT SHA:

## Profile
GitHub: REQUIRED
Supabase: REQUIRED
Zeabur: REQUIRED
Cloudflare: REQUIRED
Docker Hub: NOT_REQUIRED
Railway: NOT_REQUIRED

## GitHub
Repository:
Fork/Upstream:
Branches:
CI:
Security:
Release:

## Supabase
Project:
Database/Migrations:
Auth/OAuth:
RLS:
Storage:
Functions/Jobs:
Backup/Recovery:

## Zeabur
Project/Environment:
Source/Git SHA:
Services:
Variables:
Networking:
Port/Health:
Volumes/Persistence:
Workers/Jobs:
Deployment:

## Cloudflare
Zone:
Domain:
DNS:
TLS:
Proxy:
WAF/Rate Limits:
Pages/Workers if used:
Origin:

## Staging
Status:
Security:
Persistence:
E2E:

## Production
Release:
Zeabur Deployment:
Cloudflare Cutover:
Auth/RLS/Storage:
Workers/Jobs:
Persistence:
E2E:

## Monitoring
Status:

## Backup / Rollback / DR
GitHub:
Database:
Storage:
Zeabur Volumes:
Zeabur Config:
Cloudflare Config:
Rollback:
Recovery:

## Remaining Blockers
Exact unresolved requirements only.
