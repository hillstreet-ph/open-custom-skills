# Cloudflare Notes

Verify Zeabur origin before production DNS cutover. Discover zone/DNS/TLS/proxy/WAF/routes first. Preserve rollback target.
