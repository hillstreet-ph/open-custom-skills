# CI/CD Notes
Generate actual workflows only after repository discovery. Expected lifecycle: CI/security → migration validation → Zeabur staging → E2E → protected production. Never expose production secrets to untrusted PRs.
