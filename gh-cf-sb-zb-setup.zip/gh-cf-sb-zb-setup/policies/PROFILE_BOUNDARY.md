# Profile Boundary
Required: GitHub, Supabase, Zeabur, Cloudflare.
Not required: Docker Hub, Railway.
A Dockerfile does not automatically require Docker Hub.
