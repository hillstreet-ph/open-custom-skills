# Persistence
Classify paths as EPHEMERAL/CACHE/TEMPORARY/PERSISTENT. Assign persistent data deliberately to Supabase DB, Supabase Storage or Zeabur volume. Never delete/recreate production volumes as troubleshooting.
