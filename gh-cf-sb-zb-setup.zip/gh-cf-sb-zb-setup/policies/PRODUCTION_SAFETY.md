# Production Safety
READ before WRITE. Preserve production. High-risk changes require impact analysis, verified recovery, rollback, staging and appropriate authorization.
