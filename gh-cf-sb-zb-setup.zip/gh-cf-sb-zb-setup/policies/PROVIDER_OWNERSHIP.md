# Provider Ownership
GitHub: source/CI/release.
Supabase: DB/Auth/RLS/Storage/backend data.
Zeabur: application runtime/services/workers/persistence.
Cloudflare: public DNS/TLS/proxy/WAF/edge.
One owner per responsibility.
