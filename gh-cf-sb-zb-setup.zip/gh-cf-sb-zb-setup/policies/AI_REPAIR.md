# AI Repair
Repair owning layer only. Maximum 3 automated cycles per failure. Never weaken RLS/Auth/TLS/data isolation or perform destructive production actions to pass tests.
