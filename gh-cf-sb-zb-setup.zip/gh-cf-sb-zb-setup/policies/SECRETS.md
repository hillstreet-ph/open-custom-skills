# Secrets
Never fabricate, print, commit or document secret values. Privileged Supabase credentials stay server-side. Reports list secret names/status only.
