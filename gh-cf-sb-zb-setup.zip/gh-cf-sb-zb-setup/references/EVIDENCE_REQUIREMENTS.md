# Evidence
GitHub: checks/workflows/releases.
Supabase: migrations/Auth/RLS/Storage tests.
Zeabur: deployment/process/port/health/application/persistence.
Cloudflare: DNS/TLS/proxy/route.
Never infer success.
