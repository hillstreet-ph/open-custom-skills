# Provider Routing
github-e2e-setup → source/fork/upstream/CI/release.
supabase-e2e-setup → DB/Auth/RLS/Storage/backend data.
zeabur-e2e-setup → runtime/services/workers/volumes.
cloudflare-e2e-setup → DNS/TLS/proxy/WAF/edge.
Docker Hub/Railway → NOT_REQUIRED.
