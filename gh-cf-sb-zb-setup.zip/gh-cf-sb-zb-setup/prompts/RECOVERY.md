# Recovery
Recover from GitHub source + Supabase DB backup + Storage recovery + Zeabur configuration/volume backup + Cloudflare configuration + secret inventory. Verify dependencies and E2E after restoration.
