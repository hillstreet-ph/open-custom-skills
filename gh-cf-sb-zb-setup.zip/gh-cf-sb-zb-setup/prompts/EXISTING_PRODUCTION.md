# Existing Production
Inventory GitHub, Supabase, Zeabur and Cloudflare including production data, Auth/RLS/Storage, runtime variables, volumes, deployments, domains, backup and rollback state. Apply only minimal verified differences.
