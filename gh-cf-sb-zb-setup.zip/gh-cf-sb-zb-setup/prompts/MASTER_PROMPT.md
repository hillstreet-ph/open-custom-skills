# Master Prompt
Execute `gh-cf-sb-zb-setup/SKILL.md`. Use GitHub + Supabase + Zeabur + Cloudflare only. Docker Hub and Railway are NOT_REQUIRED. Discover first, preserve production, assign one owner per responsibility, deploy from controlled GitHub source to Zeabur, validate staging, then perform controlled Cloudflare edge cutover and production E2E verification.
