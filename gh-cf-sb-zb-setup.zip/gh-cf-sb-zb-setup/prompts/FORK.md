# Fork Mode
Preserve upstream history/license/notices. Use upstream-sync branch → compatibility review → CI/security → development → staging → Zeabur staging/E2E → release PR → main → production. Never upstream directly to main.
