# 04-SUPABASE

Invoke supabase-e2e-setup for DB/Auth/RLS/Storage/backend data/recovery.
