# 06-CLOUDFLARE

Invoke cloudflare-e2e-setup for DNS/TLS/proxy/WAF/edge after origin verification.
