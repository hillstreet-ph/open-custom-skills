# 05-ZEABUR

Invoke zeabur-e2e-setup for source deployment/runtime/services/networking/health/persistence.
