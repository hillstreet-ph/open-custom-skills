# 00-DETECT

Detect source, mode, existing production and provider compatibility.
