# 03-GITHUB

Invoke github-e2e-setup for source/fork/upstream/CI/security/release.
