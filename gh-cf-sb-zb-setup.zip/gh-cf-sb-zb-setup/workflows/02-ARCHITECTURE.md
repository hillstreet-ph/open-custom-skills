# 02-ARCHITECTURE

Map dependencies and assign one owner per responsibility.
