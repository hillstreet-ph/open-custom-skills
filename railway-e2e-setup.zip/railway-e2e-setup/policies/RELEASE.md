# Release

Prefer GitHub-controlled CI → artifact verification → Railway staging → E2E → approval → production → verification. For containers, build once/promote same artifact where practical. Prevent overlapping production promotions.
