# Secrets

Never commit, bake, print, or document secret values. Use Railway service/shared/reference/sealed variable mechanisms appropriately. Reports list names/status only. Preserve unknown production variables until usage is understood.
