# Persistence

Classify EPHEMERAL/CACHE/TEMPORARY/PERSISTENT. Durable state must not live only in disposable deployment storage. Volume/mount/restore operations are data operations. Remember volumes are runtime mounts, not build/pre-deploy mounts.
