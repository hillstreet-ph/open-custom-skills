# Production Safety

Inventory before mutation. Never blindly delete/recreate services, remove variables, change ports/domains/private networking, or detach/delete/restore volumes. Record known-good rollback state before material production changes.
