# AI Repair

Default max 3 bounded cycles. Low-risk root/build/start/port/health/non-sensitive configuration fixes may proceed through staging. Production volumes/data, DB, secrets, networking/domains, Auth, migrations and backup restore require stronger review.
