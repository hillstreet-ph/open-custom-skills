# Backup / Recovery

Deployment configuration is not a data backup. Inventory DB, volumes and external/object storage separately. Railway volume backups may be manual or scheduled according to current provider capabilities. Verify actual schedules/retention and restore implications before claiming readiness.
