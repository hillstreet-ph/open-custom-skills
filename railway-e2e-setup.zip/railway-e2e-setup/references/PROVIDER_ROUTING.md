# Provider Routing

GitHub = source/governance/CI/CD.
Docker = image/registry.
Cloudflare = DNS/TLS/edge.
Supabase = DB/Auth/RLS/Storage/data services.
Railway = runtime/services/environments/networking/variables/volumes/jobs/operations.

Avoid unnecessary responsibility overlap.
