# Variable Contract

For every required variable document:
NAME
PURPOSE
SENSITIVE?
REQUIRED?
SCOPE (service/shared/reference/sealed where applicable)
ENVIRONMENT
OWNER
STATUS

Never VALUE.
