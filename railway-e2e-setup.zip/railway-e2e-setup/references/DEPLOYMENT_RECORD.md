# Deployment Record

Record:
release
Git SHA
artifact/image/tag/digest
Railway project/environment/service
deployment identity
DB migration state
verification
previous known-good deployment.

Never include secret values.
