# Existing Production

Use EXISTING_PRODUCTION mode. Inventory projects/environments/services/variables/domains/private networking/volumes/backups/deployments before mutation. Preserve working state and data. Apply minimal changes, verify non-production where feasible, record rollback, then perform controlled production changes.
