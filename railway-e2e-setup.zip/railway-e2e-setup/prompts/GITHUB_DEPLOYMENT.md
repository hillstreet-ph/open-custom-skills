# GitHub Deployment

Use GITHUB_DEPLOYMENT mode. Discover workspace/project/environment/service/repository/branch/root/build/start/port/health and IaC state. Compose with github-e2e-setup. Preserve production, validate staging, then promote through production gates.
