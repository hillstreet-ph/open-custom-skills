# Master Prompt

Use `railway-e2e-setup/SKILL.md` as the governing procedure. Discover and audit Railway state before mutation. Preserve production services, variables, domains, volumes and data. Use current Railway IaC where appropriate, validate staging, preserve backup/rollback state, promote safely, verify production beyond the deployment health gate, and report only evidence-backed status.
