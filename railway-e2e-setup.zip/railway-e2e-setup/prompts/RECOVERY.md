# Recovery

Use RECOVERY mode. Inventory source/artifact/Railway IaC/runtime config/domains/DB/volumes/backups/external storage and known-good deployment. Restore the smallest required layer, preserve data/evidence, verify health/application/persistence, and document final recovery state.
