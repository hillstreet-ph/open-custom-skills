# Compose Migration

Use COMPOSE_MIGRATION mode. Translate Compose services, builds/images, ports, environment, volumes and networks into Railway-native services/networking/variables/volumes. Preserve data and service boundaries. Do not assume every Compose directive maps directly.
