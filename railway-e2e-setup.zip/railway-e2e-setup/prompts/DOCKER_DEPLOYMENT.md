# Docker Deployment

Use DOCKER_IMAGE_DEPLOYMENT mode. Compose with docker-e2e-setup. Prefer immutable image identity, verify in staging, then promote/deploy the same validated artifact to production where practical. Record previous deployment/image for rollback.
