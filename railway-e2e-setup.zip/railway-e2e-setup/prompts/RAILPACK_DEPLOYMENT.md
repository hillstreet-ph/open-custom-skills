# Railpack Deployment

Use RAILPACK_DEPLOYMENT mode only after stack discovery. Detect build/start/runtime requirements, configure current Railway IaC where useful, verify staging and health, then promote. Do not replace a deliberate Dockerfile without reason.
