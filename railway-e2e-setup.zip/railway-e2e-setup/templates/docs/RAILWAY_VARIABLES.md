# RAILWAY VARIABLES

Populate only from verified Railway/application state. Do not invent project/service IDs, domains, ports, variables, volume paths, deployments, credentials, or backup status.
