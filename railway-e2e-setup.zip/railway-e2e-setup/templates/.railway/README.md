# Railway Infrastructure as Code

For new/current Railway IaC, generate `.railway/railway.ts` from verified project/application state using Railway's supported IaC workflow.

Do not invent project/service IDs, domains, ports, volumes, variables, regions or credentials.

If legacy railway.toml/railway.json exists, preserve and audit it before migration.
