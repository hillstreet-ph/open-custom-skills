# railway-e2e-setup

Production Railway runtime lifecycle skill for AI engineering agents.

Covers projects/environments/services, GitHub/Docker/Railpack deployments, current Railway Infrastructure as Code, variables/secrets, private/public networking, ports/healthchecks, volumes/backups, databases/cache, workers/Cron/functions, staging/production, continuous monitoring, rollback/recovery, portability, and bounded AI remediation.

Canonical instructions: `SKILL.md`.

Never place real credentials, production data, or database dumps in this package.
