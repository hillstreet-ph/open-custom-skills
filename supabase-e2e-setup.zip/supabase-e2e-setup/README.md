# supabase-e2e-setup

Production Supabase E2E skill for AI engineering agents.

Covers PostgreSQL, schemas, migrations, Auth/OAuth, RLS, Storage/S3, REST/RPC/Realtime, Edge Functions, Cron/jobs/queues, pgvector/search, Vault/secrets, extensions, integrations, backups/PITR, disaster recovery, observability, and bounded AI remediation.

Canonical instructions: `SKILL.md`.

Never place real credentials, production database dumps, OAuth secrets, service/server keys, or S3 secrets inside this package.
