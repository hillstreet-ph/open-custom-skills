# Migrations

Create timestamped, reviewable SQL migrations from verified desired changes. Never place production credentials or raw sensitive data here. Destructive migrations require staging, recovery analysis, and appropriate approval.
