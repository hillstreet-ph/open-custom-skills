# Edge Functions

Each function should document purpose, input validation, authentication classification, authorization, secrets required, logging/error handling, staging validation, and production verification.
