# Existing Production

Use EXISTING_PRODUCTION mode. Inventory schemas, data, users, identities, policies, buckets/files, functions/jobs, migrations, secrets names, integrations, and backups before changes. Preserve identifiers and working production state. Use non-destructive migrations and staging validation; never reset or rebuild merely to standardize.
