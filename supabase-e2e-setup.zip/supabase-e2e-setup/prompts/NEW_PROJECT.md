# New Project

Use NEW_PROJECT mode. Model the application domain before creating tables. Establish migrations, Auth/OAuth, profiles/roles, RLS, Storage, API/functions/jobs/search as required, GitHub-controlled staging/production gates, backups/recovery, observability, and final production verification.
