# Master Prompt

Use `supabase-e2e-setup/SKILL.md` as the governing procedure. Discover and audit the existing Supabase state before mutation. Preserve production data/users/files, establish migration-controlled schema, secure Auth/OAuth and RLS, configure Storage/API/functions/jobs/search only as required, verify backup/recovery before high-risk work, validate staging, promote safely, and report only evidence-backed status.
