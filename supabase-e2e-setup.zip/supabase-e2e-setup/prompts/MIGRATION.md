# Migration

Use DATABASE_MIGRATION, AUTH_MIGRATION, or STORAGE_MIGRATION as appropriate. Inventory source and target, preserve identifiers/relationships/metadata, copy before cutover, verify counts/checksums/references/security, retain source until confirmed, and define rollback/recovery before production cutover.
