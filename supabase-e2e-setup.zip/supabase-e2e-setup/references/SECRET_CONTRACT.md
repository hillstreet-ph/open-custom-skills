# Secret Contract

Classify required configuration as CONFIGURED / MISSING / NOT_APPLICABLE.

Potential categories include public client configuration, privileged server credentials, DB credentials, OAuth secrets, S3 credentials, webhook secrets, function secrets, and provider deployment credentials.

Never invent values. Never report secret values.
