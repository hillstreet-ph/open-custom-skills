# Provider Routing

GitHub = source/governance/CI/CD.
Docker = container artifact.
Cloudflare = DNS/TLS/edge.
Supabase = DB/Auth/RLS/Storage/API/functions/data services.
Railway OR Zeabur = external server/workers when required.

Use only applicable providers and reuse existing infrastructure.
