# Auth / OAuth

Configure only required providers. Verify site URL, callbacks, redirect allowlists, session lifecycle, profile creation, and server/client credential boundaries. OAuth client secrets and privileged Supabase keys are never browser credentials.
