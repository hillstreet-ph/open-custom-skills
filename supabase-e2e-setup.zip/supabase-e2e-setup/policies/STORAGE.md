# Storage

Classify buckets public/private. Sensitive files default private. Align Storage policies with resource ownership. Treat S3 credentials as server-only secrets. Storage migration uses inventory → copy → checksum/metadata/reference verification → cutover; preserve source until confirmed.
