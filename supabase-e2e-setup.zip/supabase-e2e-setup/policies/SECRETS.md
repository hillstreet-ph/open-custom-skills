# Secrets

Never commit or print privileged keys, DB passwords, S3 secrets, OAuth secrets, webhook secrets, or Vault values. Store each secret in the narrowest appropriate provider trust boundary. Reports show names/status only.
