# AI Repair

Default max 3 bounded repair cycles. Low-risk deterministic fixes may proceed through branch/migration/staging validation. RLS, Auth/OAuth, identities, destructive migrations, data deletion, Storage policies, privileged keys, Vault, and production jobs/functions require stronger review. Never weaken security to make tests pass.
