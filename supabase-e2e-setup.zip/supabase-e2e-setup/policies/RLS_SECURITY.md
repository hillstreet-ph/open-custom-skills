# RLS Security

RLS is a primary authorization boundary. Test anonymous, user A, user B, role/admin, and privileged server contexts. Never disable RLS or add broad allow-all policies to fix an application. Fix the narrowest correct ownership/role policy.
