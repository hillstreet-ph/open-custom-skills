# 06-ZEABUR

Invoke zeabur-e2e-setup; deploy exact candidate digest to staging and configure runtime/persistence.
