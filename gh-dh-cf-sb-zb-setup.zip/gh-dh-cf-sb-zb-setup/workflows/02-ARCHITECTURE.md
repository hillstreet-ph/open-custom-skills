# 02-ARCHITECTURE

Map dependencies and assign one authoritative owner per responsibility.
