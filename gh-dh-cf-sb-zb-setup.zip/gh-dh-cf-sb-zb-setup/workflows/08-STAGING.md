# 08-STAGING

Run staging integration/security/E2E, persistence and digest verification.
