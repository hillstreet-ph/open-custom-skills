# 05-DOCKER

Invoke docker-e2e-setup; build, scan, publish and record immutable candidate digest.
