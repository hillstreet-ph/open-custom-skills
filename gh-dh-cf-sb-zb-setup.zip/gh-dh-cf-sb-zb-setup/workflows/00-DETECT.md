# 00-DETECT

Detect application/source, startup mode and existing production.
