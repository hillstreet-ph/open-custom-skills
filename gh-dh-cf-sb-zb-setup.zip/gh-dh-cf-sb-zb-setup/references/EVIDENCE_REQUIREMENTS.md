# Evidence Requirements
GitHub: checks/workflows/releases.
Docker: build/scan/repository/tag/digest.
Supabase: migrations/Auth/RLS/Storage tests.
Zeabur: deployment/image identity/process/port/health/workers/persistence.
Cloudflare: DNS/TLS/proxy/route.
Never infer success.
