# Profile Boundary
Required: GitHub, Docker Hub, Supabase, Zeabur, Cloudflare.
Not required: Railway.
Do not introduce Railway silently.
