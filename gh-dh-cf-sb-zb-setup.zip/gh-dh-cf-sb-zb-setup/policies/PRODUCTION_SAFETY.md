# Production Safety
READ before WRITE. Preserve production/data. High-risk DB/Auth/RLS/volume/DNS/TLS/restore operations require impact analysis, recovery readiness, rollback, staging and appropriate authorization.
