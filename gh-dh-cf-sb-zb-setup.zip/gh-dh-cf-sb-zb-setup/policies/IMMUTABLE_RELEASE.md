# Immutable Release
Build once. Scan. Publish. Record digest. Deploy exact candidate digest to staging. After verification, deploy the SAME digest to production. A digest mismatch blocks promotion.
