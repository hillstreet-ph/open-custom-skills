# Secrets
Never fabricate, print, commit, document or bake secret values into images. Privileged credentials remain server-side. Reports list names/status only.
