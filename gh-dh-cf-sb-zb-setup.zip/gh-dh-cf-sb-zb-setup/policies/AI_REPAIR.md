# AI Repair
Repair owning layer only. Maximum 3 automated repair cycles per failure. DIGEST_MISMATCH blocks promotion. Never weaken security to pass validation.
