# Provider Ownership
GitHub: source/CI/release.
Docker Hub: immutable OCI artifact.
Supabase: DB/Auth/RLS/Storage/backend data.
Zeabur: runtime/services/workers/persistence.
Cloudflare: public DNS/TLS/proxy/WAF/edge.
One owner per responsibility.
