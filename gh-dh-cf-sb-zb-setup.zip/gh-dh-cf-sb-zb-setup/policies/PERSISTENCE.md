# Persistence
Classify EPHEMERAL/CACHE/TEMPORARY/PERSISTENT. Assign durable state to Supabase DB, Supabase Storage or Zeabur volume. Never delete/recreate a production volume as a troubleshooting shortcut.
