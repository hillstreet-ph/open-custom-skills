# Existing Production
Inventory GitHub, Docker Hub, Supabase, Zeabur and Cloudflare including current Git SHA, image digest, migrations, Auth/RLS/Storage, variables, volumes, deployment, domain, backups and rollback state. Apply only minimal verified differences.
