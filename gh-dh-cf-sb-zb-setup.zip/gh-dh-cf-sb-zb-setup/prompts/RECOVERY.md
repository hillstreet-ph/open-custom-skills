# Recovery
Recover from GitHub source + known-good Docker digest + Supabase DB backup + Storage recovery + Zeabur config/volume backup + Cloudflare config + secret inventory. Verify release identity and production E2E after restoration.
