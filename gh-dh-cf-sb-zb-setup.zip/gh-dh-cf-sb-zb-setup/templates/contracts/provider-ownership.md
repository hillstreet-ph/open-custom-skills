# Provider Ownership
GitHub: REQUIRED — source/fork/CI/release
Docker Hub: REQUIRED — immutable OCI artifact
Supabase: REQUIRED — DB/Auth/RLS/Storage/backend data
Zeabur: REQUIRED — runtime/services/workers/persistence
Cloudflare: REQUIRED — DNS/TLS/proxy/WAF/edge
Railway: NOT_REQUIRED
