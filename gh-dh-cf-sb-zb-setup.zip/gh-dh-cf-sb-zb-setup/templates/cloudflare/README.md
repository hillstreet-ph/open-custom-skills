# Cloudflare Notes
Verify Zeabur origin and intended digest before production cutover. Discover DNS/TLS/proxy/WAF/routes first and preserve rollback targets.
