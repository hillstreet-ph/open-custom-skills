# Docker Notes
Discover existing Dockerfile/build/registry first. Build once, scan, publish and preserve immutable digest. Runtime secrets must not be baked into images.
