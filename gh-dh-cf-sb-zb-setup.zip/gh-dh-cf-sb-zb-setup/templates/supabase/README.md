# Supabase Notes
Discover schema/Auth/RLS/Storage/backups first. Never invent project IDs, schema state, policies or secret values.
