# GH-DH-CF-SB-ZB E2E REPORT

## Overall
STATUS:
MODE:
APPLICATION:
VERSION:
GIT SHA:

## Profile
GitHub: REQUIRED
Docker Hub: REQUIRED
Supabase: REQUIRED
Zeabur: REQUIRED
Cloudflare: REQUIRED
Railway: NOT_REQUIRED

## GitHub
Repository:
Fork/Upstream:
Branches:
CI:
Security:
Release:

## Docker Hub
Repository:
Image:
Tag:
Digest:
Architecture:
Security Scan:

## Supabase
Project:
Database/Migrations:
Auth/OAuth:
RLS:
Storage:
Functions/Jobs:
Backup/Recovery:

## Zeabur
Project/Environment:
Expected Image/Digest:
Deployed Digest:
Services:
Variables:
Networking:
Port/Health:
Volumes/Persistence:
Workers/Jobs:
Deployment:

## Cloudflare
Zone:
Domain:
DNS:
TLS:
Proxy:
WAF/Rate Limits:
Pages/Workers if used:
Origin:

## Staging
Git SHA:
Docker Digest:
Zeabur Deployment:
Migration:
Auth/RLS/Storage:
Workers/Jobs:
Persistence:
Cloudflare:
Security:
E2E:

## Production
Release:
Git SHA:
Staging Digest:
Production Digest:
Digest Match:
Zeabur Deployment:
Migration:
DNS/TLS/Proxy:
Auth/RLS/Storage:
Workers/Jobs:
Persistence:
E2E:

## Monitoring
Status:

## Backup / Rollback / DR
GitHub:
Docker Artifact:
Database:
Storage:
Zeabur Volumes:
Zeabur Config:
Cloudflare Config:
Rollback:
Recovery:

## Remaining Blockers
Exact unresolved requirements only.
