# Zeabur Notes
Discover project/environments/services/variables/ports/health/volumes first. Staging and production must use the same verified Docker digest for normal promotion.
