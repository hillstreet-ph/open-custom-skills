# Evidence Requirements

GitHub: checks/workflows/releases.
Supabase: migrations/Auth/RLS/Storage tests.
Cloudflare: deployment/DNS/TLS/route/application response.

Never infer success.
