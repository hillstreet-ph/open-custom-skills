# Provider Routing

github-e2e-setup → source/fork/upstream/CI/release.
supabase-e2e-setup → DB/Auth/RLS/Storage/backend data services.
cloudflare-e2e-setup → Pages/Workers/DNS/TLS/WAF/edge.

Docker Hub/Railway/Zeabur = NOT_REQUIRED.
