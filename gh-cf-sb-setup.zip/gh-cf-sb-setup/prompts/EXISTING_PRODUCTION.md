# Existing Production

Inventory GitHub, Supabase, Cloudflare, production data, Auth/RLS/Storage, deployments, domains, secrets names, backups and rollback state before mutation. Make minimal changes and preserve working state.
