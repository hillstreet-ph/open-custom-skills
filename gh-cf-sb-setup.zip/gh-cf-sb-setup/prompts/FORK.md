# Fork Mode

Preserve upstream history/licenses/notices. Establish UPSTREAM and controlled ORIGIN. Never merge upstream directly to main. Route upstream through upstream-sync branch, compatibility review, CI/security, development, staging, E2E and release approval.
