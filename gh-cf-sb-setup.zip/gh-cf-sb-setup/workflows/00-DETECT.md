# 00 DETECT

Detect source, existing production and profile compatibility.
