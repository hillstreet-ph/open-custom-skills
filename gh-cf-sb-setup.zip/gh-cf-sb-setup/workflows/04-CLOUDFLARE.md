# 04 CLOUDFLARE

Invoke cloudflare-e2e-setup for Pages/Workers/DNS/TLS/WAF/edge.
