# 02 GITHUB

Invoke github-e2e-setup for fork/upstream/branches/CI/security/releases.
