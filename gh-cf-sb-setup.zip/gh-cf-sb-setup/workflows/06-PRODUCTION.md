# 06 PRODUCTION

Apply gates, deploy validated release, perform controlled DNS/domain changes and verify.
