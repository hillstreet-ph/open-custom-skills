# Provider Ownership

GitHub: REQUIRED — source/fork/CI/release
Supabase: REQUIRED — DB/Auth/RLS/Storage/backend data
Cloudflare: REQUIRED — Pages/Workers/DNS/TLS/edge
Docker Hub: NOT_REQUIRED
Railway: NOT_REQUIRED
Zeabur: NOT_REQUIRED
