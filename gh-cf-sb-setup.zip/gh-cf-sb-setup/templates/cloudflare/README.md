# Cloudflare Template Notes

Discover framework and current Cloudflare resources before generating Pages/Workers configuration. Do not invent account IDs, zone IDs, project names, routes, domains or secrets.
