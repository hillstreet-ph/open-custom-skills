# Supabase Template Notes

Discover project/schema/migration/Auth/RLS/Storage state before generating configuration or migrations. Never invent project IDs, URLs, keys, policies or production schema state.
