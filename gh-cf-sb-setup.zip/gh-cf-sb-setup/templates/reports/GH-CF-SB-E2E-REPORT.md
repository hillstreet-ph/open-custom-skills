# GH-CF-SB E2E REPORT

## Overall
STATUS:
MODE:
APPLICATION:
VERSION:
GIT SHA:

## Profile
GitHub: REQUIRED
Supabase: REQUIRED
Cloudflare: REQUIRED
Docker Hub: NOT_REQUIRED
Railway: NOT_REQUIRED
Zeabur: NOT_REQUIRED

## GitHub
Repository:
Fork:
Upstream:
Branches:
CI:
Security:
Release:

## Supabase
Project:
Database:
Migrations:
Auth:
OAuth:
RLS:
Storage:
Functions:
Jobs:
Vector:
Backup:

## Cloudflare
Account:
Zone:
Pages:
Workers:
Domain:
DNS:
TLS:
Proxy:
WAF:
Rate Limits:
Cache:

## Staging
Status:
E2E:
Security:

## Production
Release:
Cloudflare Deployment:
Domain:
DNS/TLS:
Supabase Verification:
E2E:

## Monitoring
Status:

## Backup / Recovery
GitHub:
Database:
Storage:
Cloudflare Configuration:

## Rollback
Source:
Database:
Cloudflare:
DNS:

## Remaining Blockers
Exact unresolved requirements only.
