# Secrets

Never fabricate, print, commit, document or expose secret values. Browser code receives only client-safe configuration. Reports list names/status only.
