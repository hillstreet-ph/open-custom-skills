# Profile Boundary

Required: GitHub, Supabase, Cloudflare.
Excluded: Docker Hub, Railway, Zeabur.

Do not introduce excluded providers. Return PROFILE_INCOMPATIBLE if architecture genuinely needs a dedicated persistent/container runtime.
