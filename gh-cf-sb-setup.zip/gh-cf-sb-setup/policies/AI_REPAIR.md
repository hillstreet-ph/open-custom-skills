# AI Repair

Repair only the owning provider/layer. Maximum 3 automated cycles per failure. Never weaken security or perform high-risk production data/Auth/DNS operations without stronger review.
