# RLS Security

RLS is a primary authorization boundary for exposed Supabase data. Test anonymous, cross-user and privileged identities. Never disable RLS to make the application work.
