# Data Recovery

Database and Storage are separate recovery layers. Never assume DB backup covers Storage objects. Preserve source data during migration until destination verification.
