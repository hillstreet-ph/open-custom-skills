# Production Safety

READ before WRITE. Preserve production. High-risk changes require impact analysis, verified recovery, rollback plan, staging and appropriate authorization before application.
