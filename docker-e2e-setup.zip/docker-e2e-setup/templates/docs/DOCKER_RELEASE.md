# DOCKER RELEASE

Populate from verified project state. Do not invent credentials, paths, ports, images, or provider resources.
