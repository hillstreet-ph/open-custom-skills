# Production Safety

- Preserve deployed image references and known-good digests.
- Never delete production volumes or user data.
- Build once and promote the same immutable artifact where possible.
- Production success requires health/application verification.
- Assess database compatibility before rollback.
