# AI Repair Policy

Use bounded `ai-fix/*` remediation through GitHub. Maximum default: 3 repair cycles. Low-risk deterministic Docker/build fixes may be automated. Persistence, migrations, secrets, networking, security capabilities, and user-data paths require stronger review.
