# Persistence Policy

Classify filesystem paths as ephemeral, cache, temporary, or persistent. Persistent state must live in durable volumes, databases, or object storage. Container layers are not durable application storage.
