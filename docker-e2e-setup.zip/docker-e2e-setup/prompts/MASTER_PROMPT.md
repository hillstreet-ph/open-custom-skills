# Master Prompt

Use `docker-e2e-setup/SKILL.md` as the governing procedure. Inspect the project before modifying it. Establish the highest safely verifiable Docker lifecycle state, integrate with `github-e2e-setup`, use Docker Hub when applicable, and use Railway OR Zeabur when a runtime is required. Preserve data and existing production state. Report only evidence-backed status.
