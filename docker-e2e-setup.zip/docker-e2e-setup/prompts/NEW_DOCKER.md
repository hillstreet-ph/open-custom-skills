# New Docker Invocation

Use NO_DOCKER mode. Detect the stack and runtime, design a production Dockerfile and ignore rules, identify ports/health/persistence, build and run-test, configure Docker Hub and GitHub Actions when authorized, validate security and architectures, then establish staging, release, production verification, rollback, and recovery.
