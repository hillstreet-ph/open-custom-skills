# Existing Docker Invocation

Use the appropriate existing mode. Audit Dockerfile/Compose/registry/deployment first. Preserve working configuration and production data. Repair gaps rather than replacing the system blindly. Revalidate build, runtime health, security, registry traceability, staging, production, rollback, and persistence.
