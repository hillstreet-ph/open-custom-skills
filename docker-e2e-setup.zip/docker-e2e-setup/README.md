# docker-e2e-setup

Portable production Docker/Docker Hub E2E skill for AI engineering agents.

## Covers

- Docker discovery/audit
- Dockerfile + `.dockerignore`
- Compose
- BuildKit / Buildx
- amd64 / arm64 validation
- Docker Hub
- GitHub Actions integration
- immutable SHA/digest tagging
- SemVer releases
- security scans
- SBOM/provenance policy
- staging → production promotion
- Railway OR Zeabur runtime composition
- Supabase / Cloudflare separation
- persistence
- rollback / recovery
- bounded AI diagnosis and repair

Canonical instructions are in `SKILL.md`.

Never place real credentials inside this package.
