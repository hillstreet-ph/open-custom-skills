# Tagging

Recommended:
- `<semver>`
- `<major>.<minor>`
- `<major>`
- `sha-<commit>`
- `latest` convenience pointer
- `staging-<sha>` or `<version>-rc.<n>` prerelease

Always record production digest.
