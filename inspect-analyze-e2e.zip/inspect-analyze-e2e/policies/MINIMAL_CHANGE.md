# Minimal Change
Apply the smallest correct delta. Preserve unrelated working systems and existing project conventions. Do not introduce unnecessary providers/frameworks/services/dependencies.
