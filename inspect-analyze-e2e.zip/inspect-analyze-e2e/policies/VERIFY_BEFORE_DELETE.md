# Verify Before Delete
Check references, production use, backup, rollback, canonical replacement, dependencies and authorization. Default is PRESERVE.
