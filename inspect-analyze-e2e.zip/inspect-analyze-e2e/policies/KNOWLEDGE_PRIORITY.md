# Knowledge Priority
Prefer verified current production/repository/provider/DB/deployment state over historical docs, prior handoffs or memory. Memory is supplementary and must be revalidated for critical facts.
