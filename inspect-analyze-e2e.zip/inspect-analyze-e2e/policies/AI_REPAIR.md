# AI Repair
Repair owning layer only. Maximum 3 autonomous repair cycles for the same failure: diagnose → minimal patch → test → verify. Then stop and report evidence/blocker.
