# Inspect Before Edit
Identify canonical resource, generated status, dirty worktree, active agent ownership, dependencies, scope and tests before editing.
