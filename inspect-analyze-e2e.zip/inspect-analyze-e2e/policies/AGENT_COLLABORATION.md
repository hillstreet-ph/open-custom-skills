# Agent Collaboration
Assign agent/task/write scope/dependencies/status/handoff. Avoid overlapping high-risk mutations. Use existing collaboration locks when supported; do not invent competing lock infrastructure.
