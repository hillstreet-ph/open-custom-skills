# Production Safety
Production preservation outranks cleanup. High-risk changes require impact analysis, recovery readiness, rollback, staging where applicable, and appropriate authorization.
