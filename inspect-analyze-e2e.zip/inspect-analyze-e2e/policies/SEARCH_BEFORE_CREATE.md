# Search Before Create
Search exact and semantic matches in repository, provider, DB, configuration and active agent work. Reuse/verify/repair/complete existing resources. Create only when genuinely missing.
