# 08-GAP-IMPACT

Build requirement matrix, gap analysis, impact analysis, risk and blast radius.
