# 02-INFRASTRUCTURE

Discover provider ownership and actual resources before creating infrastructure.
