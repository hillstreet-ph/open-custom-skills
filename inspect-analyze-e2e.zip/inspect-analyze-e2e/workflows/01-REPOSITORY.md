# 01-REPOSITORY

Find project root; inspect Git state, tree, frameworks, entrypoints, dependencies, tests and configuration.
