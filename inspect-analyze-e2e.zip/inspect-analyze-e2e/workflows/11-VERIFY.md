# 11-VERIFY

Run tests/regression/deployment verification and require evidence for success.
