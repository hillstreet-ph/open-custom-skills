# 03-DATA-AUTH

Inspect DB/schema/migrations/Auth/RLS/Storage and recovery state.
