# 06-COLLABORATION

Inspect active agent work and assign non-overlapping write scopes/dependencies/locks/handoffs.
