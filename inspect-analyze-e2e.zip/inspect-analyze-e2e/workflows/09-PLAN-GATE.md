# 09-PLAN-GATE

Define minimal delta, execution order, tests, rollback and evaluate execution gate.
