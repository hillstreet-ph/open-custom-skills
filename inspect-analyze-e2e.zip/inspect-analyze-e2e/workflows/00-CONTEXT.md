# 00-CONTEXT

Collect authorized project instructions, docs, knowledge, handoffs and task context.
