# 05-KNOWLEDGE

Inspect docs/ADRs/fork customizations/previous handoffs and revalidate important historical context.
