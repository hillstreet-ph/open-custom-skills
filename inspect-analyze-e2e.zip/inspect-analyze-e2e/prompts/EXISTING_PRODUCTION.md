# Existing Production
Treat verified live production as critical evidence. Inventory release identity, Git SHA/image, DB migration, runtime, DNS, storage, volumes, workers/jobs and integrations. Preserve working state. Verify backup/recovery before high-risk changes. Never rebuild merely because production is unhealthy; diagnose root cause first.
