# Master Prompt
Execute `inspect-analyze-e2e/SKILL.md` before making project changes.

Start in INSPECT MODE. Reconstruct current project state from authorized live sources, repository state, provider state, database, docs, handoffs and relevant knowledge. Search exact and semantic equivalents before creating anything. Detect active agent work, duplicates, conflicts and drift. Build a requirement matrix, impact analysis, minimal change plan, test plan and rollback where required. Only then perform the smallest authorized change and verify it with evidence.
