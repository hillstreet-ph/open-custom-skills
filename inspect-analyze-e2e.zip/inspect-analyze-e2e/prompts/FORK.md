# Fork Inspection
Identify origin/upstream/version/history/license/local customizations/branding/schema/deployment changes before edits or sync. Never replace a customized fork with a fresh upstream clone. Route upstream changes through compatibility review and verified integration.
