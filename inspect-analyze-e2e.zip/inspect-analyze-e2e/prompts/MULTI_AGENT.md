# Multi-Agent Collaboration
Synchronize project knowledge first. Assign non-overlapping write scopes and dependencies. Check branches/PRs/worktrees/handoffs/locks before edits. Use explicit resource ownership for DB schema, production deploy, DNS, Auth and release operations. Require structured handoff and evidence.
