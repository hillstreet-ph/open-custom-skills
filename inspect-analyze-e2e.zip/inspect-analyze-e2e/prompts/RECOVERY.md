# Recovery Inspection
Before rebuilding, identify last known-good commit/release/image, DB state, configuration, provider state and recent changes. Prefer controlled recovery when safer than recreation.
