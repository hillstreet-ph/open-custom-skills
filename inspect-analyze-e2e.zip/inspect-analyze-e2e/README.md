# inspect-analyze-e2e

Universal pre-change inspection and AI-agent collaboration control layer.

Core invariant:

**Search before create. Inspect before edit. Verify before delete. Coordinate before parallel change.**

Run this skill before implementation profiles or provider-specific skills.

Canonical instructions: `SKILL.md`.
