# Evidence
Use file/reference, commit/PR/workflow/test/migration/provider resource/deployment/HTTP/health/DB query/config state. Never claim fixed/deployed/configured/working/verified without evidence.
