# Source Priority
1 verified current production
2 current repository
3 current provider configuration
4 current DB/schema
5 current deployment configuration
6 approved architecture docs
7 recent merged PRs/commits
8 current project instructions
9 maintained knowledge base
10 prior handoffs
11 historical conversation/memory
12 assumptions
