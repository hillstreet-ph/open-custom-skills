# Collaboration Templates
Use AGENT-COLLABORATION, CHANGE-JOURNAL and INSPECT-ANALYZE-HANDOFF to coordinate agents. Prefer existing platform-native task/lock mechanisms when available.
