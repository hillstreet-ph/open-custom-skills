# Inventory Templates
Use PROJECT-SNAPSHOT, PROVIDER-MAP, RESOURCE-INVENTORY and REQUIREMENT-MATRIX to avoid repeated rediscovery and duplicate creation.
