# AGENT COLLABORATION
| Agent | Task | Write Scope | Dependencies | Locks | Status | Last Update | Handoff |
|---|---|---|---|---|---|---|---|
