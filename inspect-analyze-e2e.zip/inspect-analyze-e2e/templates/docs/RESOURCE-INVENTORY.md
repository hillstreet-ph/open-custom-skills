# RESOURCE INVENTORY
| Type | Provider/Location | Resource | Environment | Purpose | Owner | Status | Evidence |
|---|---|---|---|---|---|---|---|
No secret values.
