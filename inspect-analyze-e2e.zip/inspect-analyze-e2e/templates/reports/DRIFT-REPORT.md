# DRIFT REPORT
| Domain | Declared State | Actual State | Evidence | Impact | Recommended Action |
|---|---|---|---|---|---|
