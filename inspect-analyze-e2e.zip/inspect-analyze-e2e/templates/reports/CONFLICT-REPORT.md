# CONFLICT REPORT
| Resource | Agent/Branch/Task A | Agent/Branch/Task B | Conflict | Impact | Recommended Resolution | Required Owner |
|---|---|---|---|---|---|---|
