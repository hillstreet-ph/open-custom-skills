# INSPECT-ANALYZE-E2E REPORT
## Overall
PROJECT:
REQUEST:
MODE:
RISK:
STATUS:

## Context Sources
Repository:
Documentation:
Knowledge Base:
Memory/Previous Context:
Provider State:
Previous Agent Handoff:

## Repository
Repository:
Branch:
Git SHA:
Origin:
Upstream:
Fork:
Dirty Worktree:
Open PRs:
Active Branches:

## Architecture
Frontend:
Backend:
API:
Database:
Auth:
Storage:
Runtime:
Registry:
Edge:
Workers:
Jobs:
External Integrations:

## Provider Ownership
See PROVIDER-MAP.

## Existing Functionality
| Requirement | Implementation | Evidence | Status |
|---|---|---|---|

## Agent Collaboration
Active Agents:
Tasks:
Write Scopes:
Locks:
Conflicts:
Handoffs:

## Duplicate / Drift / Conflict
Summary:

## Gap Analysis
See requirement matrix.

## Impact Analysis
Data:
Users:
Auth:
API:
Storage:
Runtime:
Deployment:
DNS:

## Change Plan
Summary:

## Blockers
Exact blockers only.

## Recommendation
NO_CHANGE_REQUIRED / MINIMAL_CHANGE_REQUIRED / COORDINATED_CHANGE_REQUIRED / HIGH_RISK_CHANGE_REQUIRES_GATE / BLOCKED
