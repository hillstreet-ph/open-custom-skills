# INSPECT-ANALYZE CHANGE REPORT
## Before
State:
Release:
Known Issues:

## Planned Delta
Changes Intended:

## Actual Changes
Files:
Database:
Infrastructure:
Configuration:
Dependencies:

## Tests
| Test | Result | Evidence |
|---|---|---|

## Deployment
Environment:
Release:
Status:

## Regression
Existing Features:
Auth:
Database:
API:
Storage:
Workers:

## Conflicts / Duplicates
Detected:
Resolved:
Remaining:

## Knowledge Updated
Docs:
Snapshot:
Handoff:

## Rollback
Available:
Procedure:

## Final Status
PRODUCTION_VERIFIED / STAGING_VERIFIED / PARTIALLY_VERIFIED / BLOCKED / FAILED
