# DUPLICATE REPORT
| Resource A | Resource B | Semantic Purpose | Evidence | Canonical Owner | Recommendation | Removal Risk |
|---|---|---|---|---|---|---|
Do not automatically delete duplicates.
