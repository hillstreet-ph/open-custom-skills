# zeabur-e2e-setup

Production Zeabur runtime lifecycle skill for AI engineering agents.

Covers project/environment/service discovery, GitHub and Docker deployments, variables/secrets, ports, health checks, domains/networking, persistent volumes, workers/jobs, staging/production promotion, observability, backup, rollback, recovery, portability, and bounded AI remediation.

Canonical instructions: `SKILL.md`.

Never include real credentials or production data in this package.
