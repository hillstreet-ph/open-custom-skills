# Production Safety

Inventory before mutation. Never blindly delete/recreate production projects/services, remove variables, change ports/domains, or detach/delete volumes. Record rollback state before material production changes.
