# Secrets

Never commit, bake, print, or document secret values. Use secure runtime/provider stores. Reports list names/status only. Preserve unknown production variables until usage is understood.
