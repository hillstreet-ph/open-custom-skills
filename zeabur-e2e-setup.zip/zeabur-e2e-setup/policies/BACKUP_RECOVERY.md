# Backup / Recovery

Deployment configuration is not a data backup. Inventory DB, volumes and external/object storage separately. Record owner, method, frequency, retention and restore path. Recovery must reconstruct source/artifact/runtime config/secrets/domains/data.
