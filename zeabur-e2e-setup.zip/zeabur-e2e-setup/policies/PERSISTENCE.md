# Persistence

Classify EPHEMERAL/CACHE/TEMPORARY/PERSISTENT. Persistent data must not live only in disposable container state. Production volume/mount changes are high risk. Verify safe restart persistence where appropriate and maintain backup/restore paths.
