# AI Repair

Default maximum 3 bounded repair cycles. Low-risk build/start/port/health/non-sensitive configuration fixes may proceed through staging. Production volumes/data, DB, secrets, domains, Auth, network exposure, persistent paths, and migrations require stronger review.
