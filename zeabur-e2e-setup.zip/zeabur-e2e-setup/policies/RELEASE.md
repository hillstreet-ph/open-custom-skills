# Release

Prefer GitHub-governed CI → artifact verification → staging → E2E → approval → production → verification. For containers, build once and promote the same immutable artifact where practical. Prevent overlapping production promotions.
