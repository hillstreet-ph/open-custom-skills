# Deployment Record

Record:
release version
Git SHA
image/tag/digest where applicable
workspace/project/environment
service
deployment identity
timestamp
verification status
previous known-good release/deployment.

Never include secrets.
