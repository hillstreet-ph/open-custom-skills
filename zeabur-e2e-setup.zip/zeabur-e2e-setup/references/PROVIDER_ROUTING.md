# Provider Routing

GitHub = source/governance/CI/CD.
Docker = image/registry.
Cloudflare = DNS/TLS/edge.
Supabase = DB/Auth/RLS/Storage/data services.
Zeabur = runtime/services/networking/volumes/operations.

Avoid unnecessary responsibility overlap.
