# Variable Contract

For each required variable document:
NAME
PURPOSE
SENSITIVE?
REQUIRED?
ENVIRONMENT
OWNER
STATUS

Never document the value.
