# Docker Image Deployment

Use DOCKER_IMAGE_DEPLOYMENT mode. Compose with docker-e2e-setup. Prefer immutable image identity, stage and verify the artifact, then deploy/promote the same validated artifact to production where supported. Record previous image/deployment for rollback.
