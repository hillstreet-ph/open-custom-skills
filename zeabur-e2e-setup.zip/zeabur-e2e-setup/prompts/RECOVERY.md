# Recovery

Use RECOVERY mode. Inventory source, artifact, runtime configuration, domains, DB, volumes, external storage and last known-good deployment. Preserve evidence/data. Restore the smallest required layer, verify health/application/persistence, and document the resulting recovery state.
