# GitHub Deployment

Use GITHUB_DEPLOYMENT mode. Discover workspace/project/service/repository/branch/root/build/start/port/health. Compose with github-e2e-setup. Preserve production state, deploy staging first, verify application dependencies and persistence, then promote through production gates.
