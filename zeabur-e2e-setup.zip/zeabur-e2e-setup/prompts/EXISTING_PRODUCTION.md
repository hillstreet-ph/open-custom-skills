# Existing Production

Use EXISTING_PRODUCTION mode. Inventory all projects/environments/services/variables/domains/volumes/deployments before mutation. Preserve working state and persistent data. Make minimal changes, verify staging/non-production where feasible, record rollback state, then apply controlled production changes.
