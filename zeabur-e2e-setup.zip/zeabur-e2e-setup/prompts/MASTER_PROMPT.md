# Master Prompt

Use `zeabur-e2e-setup/SKILL.md` as the governing procedure. Discover and audit existing Zeabur state before mutation. Preserve production services, variables, domains and volumes. Classify deployment source, configure the minimum correct runtime, validate staging, preserve rollback/recovery state, promote safely, and report only evidence-backed status.
