# ZEABUR ROLLBACK

Populate only from verified Zeabur/application state. Do not invent project IDs, service IDs, domains, variables, volume paths, deployment IDs, credentials, or backup status.
