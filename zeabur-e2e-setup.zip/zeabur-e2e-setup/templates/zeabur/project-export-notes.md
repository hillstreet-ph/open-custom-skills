# Zeabur Project Export Notes

When supported/appropriate, project configuration export can help reconstruct deployment topology. It is not a backup of application/database/volume data.

Before using an exported template/configuration:
- review secret handling
- review environment-specific values
- review volumes and data dependencies
- review domains
- validate in non-production first.
