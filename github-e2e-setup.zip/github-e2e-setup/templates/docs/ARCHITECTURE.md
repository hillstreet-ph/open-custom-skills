# ARCHITECTURE

Populate from verified project state. Do not invent infrastructure or credentials.
