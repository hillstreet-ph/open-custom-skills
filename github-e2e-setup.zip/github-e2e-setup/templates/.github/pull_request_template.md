# Summary

## Reason

## Change Type
- [ ] Feature
- [ ] Fix
- [ ] Dependency
- [ ] Upstream sync
- [ ] Release
- [ ] Hotfix
- [ ] Infrastructure

## Validation
- [ ] Lint/typecheck
- [ ] Unit/integration tests
- [ ] Build
- [ ] Security checks
- [ ] Staging/E2E if applicable

## Impact
**Security:**  
**Database/migrations:**  
**Deployment:**  

## Rollback
Describe the known-good rollback path.
