# Workflow Templates

Workflows are intentionally not hard-coded here because the skill must detect the actual stack and provider topology before generating CI/CD. Do not install irrelevant jobs or assume package-manager commands.
