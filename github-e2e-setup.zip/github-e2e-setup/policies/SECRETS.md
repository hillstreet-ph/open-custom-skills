# Secrets Policy

- Real secrets never enter Git history, examples, logs, PR bodies, or reports.
- Use GitHub/provider secret stores.
- Report secret names/status only.
- Never fabricate a secret.
- Never expose production secrets to untrusted PR code.
