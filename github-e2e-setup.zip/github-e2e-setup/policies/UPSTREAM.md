# Upstream Policy

FORK mode only. Upstream changes enter `upstream-sync/*`, then PR to `development`, then staging validation, then release approval to `main`. Preserve deliberate fork customizations and never blindly resolve conflicts with `ours`/`theirs`.
