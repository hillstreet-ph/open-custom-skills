# AI Repair Policy

AI repairs use `ai-fix/*`, finite retries, risk classification, and full revalidation. Low-risk deterministic repairs may be automated. Auth, authorization, RLS, destructive migrations, data deletion, secrets, DNS, networking, storage, and security controls require stronger review/approval.
