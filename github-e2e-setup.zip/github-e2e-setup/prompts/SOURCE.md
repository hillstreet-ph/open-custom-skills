# Source Invocation

Use the appropriate SOURCE-family mode: CLONE_INDEPENDENT, IMPORT, UPLOAD, GENERATED, EXISTING_REPOSITORY, or PRODUCTION_EXISTING. Audit for secrets before first push, preserve Git history when available, then establish `development → staging → main → production` with governance, Actions, security, versioning, provider integrations, validation, rollback, and bounded AI-assisted repair.
