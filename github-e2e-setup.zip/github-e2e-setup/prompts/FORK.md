# Fork Invocation

Use FORK mode. Preserve the GitHub fork relationship and local customizations. Set up safe upstream detection and `upstream-sync/* → development → staging → main`, with CI/security, release gates, approval, production verification, versioning, rollback, and bounded AI-assisted repair. Never sync upstream directly to production.
