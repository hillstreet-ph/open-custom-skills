# Master Prompt

Use the `github-e2e-setup` skill in `SKILL.md` as the governing procedure. Take the supplied repository/source from discovery through the highest verifiable lifecycle state. Classify it as FORK or SOURCE-family mode first. Inspect before modifying, preserve working production state, configure GitHub governance/Actions/environments/secrets contracts, integrate applicable provider skills, validate staging before main, and report only evidence-backed results.
