# Provider Routing

GitHub is the release control plane. Compose with Docker Hub for images, Supabase for DB/Auth/Storage, Cloudflare for DNS/TLS/edge, and Railway OR Zeabur for server runtime. Detect existing resources first and reuse them rather than duplicating them.
