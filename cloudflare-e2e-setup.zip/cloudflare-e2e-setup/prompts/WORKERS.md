# Workers Invocation

Use WORKERS or HYBRID mode. Audit Wrangler, routes, custom domains, compatibility settings, bindings, variables/secrets, and existing deployments. Configure only required resources, deploy staging first, verify routes/application behavior, then promote with rollback traceability.
