# Master Prompt

Use `cloudflare-e2e-setup/SKILL.md` as the governing procedure. Discover and audit the existing Cloudflare account/zone before changes. Preserve working DNS and production state, classify the architecture, configure only required Cloudflare capabilities, integrate with GitHub and applicable provider skills, validate staging before production, preserve rollback state, and report only evidence-backed results.
