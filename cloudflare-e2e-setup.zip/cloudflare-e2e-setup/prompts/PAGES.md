# Pages Invocation

Use PAGES or HYBRID mode. Detect framework/build/output settings, preserve existing project/domain configuration, separate preview/production, secure variables/secrets, integrate GitHub gates, verify preview/staging, then promote and verify the production custom domain.
