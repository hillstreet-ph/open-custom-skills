# External Origin Invocation

Use EXTERNAL_ORIGIN or HYBRID mode. Verify the Railway/Zeabur/other origin first, inventory DNS and TLS, preserve mail/service records, configure correct proxy/DNS behavior, test staging, record previous DNS state, perform controlled cutover, and verify edge plus origin health.
