# DNS Safety

Inventory before mutation. Preserve mail, SPF/DKIM/DMARC, verification, OAuth, and service records. Treat nameserver and production DNS changes as high risk. Record previous type/name/content/proxy/TTL before cutover.
