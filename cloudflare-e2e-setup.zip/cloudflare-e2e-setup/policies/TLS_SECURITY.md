# TLS and Security

Prefer strong end-to-end HTTPS and origin certificate validation. Do not weaken TLS to mask origin errors. Treat HSTS, WAF, Access, DNSSEC, and production security-routing changes as high risk. Test CSP/security rules against real application requirements.
