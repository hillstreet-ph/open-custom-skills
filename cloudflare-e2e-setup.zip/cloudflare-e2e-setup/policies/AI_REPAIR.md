# AI Repair

Use bounded diagnosis and repair. Default max 3 cycles. Low-risk deterministic build/config fixes may be automated. Nameservers, production DNS, DNSSEC, TLS mode, HSTS, WAF, Access, production secrets, authentication routing, and origin replacement require stronger review.
