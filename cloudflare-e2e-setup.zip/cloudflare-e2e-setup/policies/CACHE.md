# Cache Policy

Classify static, HTML, API, and private/authenticated responses. Cache fingerprinted static assets aggressively when safe. Be conservative with dynamic HTML. Do not shared-cache personalized/authenticated API responses unless explicitly designed for it.
