# Secrets

Use scoped Cloudflare API tokens and provider/GitHub secret stores. Never commit tokens or plaintext Worker secrets. Never expose privileged credentials to untrusted PR code. Report names/status only.
