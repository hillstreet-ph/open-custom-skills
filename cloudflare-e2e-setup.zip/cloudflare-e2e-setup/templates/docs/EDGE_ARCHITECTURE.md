# EDGE ARCHITECTURE

Populate from verified Cloudflare/project state. Do not invent account IDs, zone IDs, records, domains, routes, or credentials.
