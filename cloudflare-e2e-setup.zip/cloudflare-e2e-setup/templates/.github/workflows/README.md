# Cloudflare Workflow Templates

Generate only after topology discovery.

Typical capabilities:
- Pages preview/staging deploy
- Worker validation/deploy
- production deploy behind GitHub environment gates
- deployment concurrency
- post-deploy DNS/TLS/application verification

Never expose privileged Cloudflare tokens to untrusted pull requests.
