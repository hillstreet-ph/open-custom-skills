# Provider Routing

GitHub = release control plane.
Docker Hub = registry.
Supabase = DB/Auth/Storage.
Cloudflare = DNS/TLS/edge/Pages/Workers/security.
Railway OR Zeabur = server runtime when required.

Use only applicable providers and reuse existing infrastructure.
