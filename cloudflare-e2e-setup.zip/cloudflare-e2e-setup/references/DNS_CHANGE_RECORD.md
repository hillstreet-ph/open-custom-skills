# DNS Change Record

For material production DNS changes record:

- hostname
- type
- previous content
- previous proxy state
- previous TTL
- new content
- new proxy state
- purpose
- verification result
- rollback result if used

Never include secret values.
