# cloudflare-e2e-setup

Portable Cloudflare production lifecycle skill for AI engineering agents.

## Covers

- account/zone discovery
- DNS and nameserver safety
- DNSSEC
- proxy/CDN
- TLS/HTTPS/HSTS policy
- Pages
- Workers/Wrangler
- bindings and secrets
- custom domains
- WAF/rate limiting/security headers
- caching/redirects
- GitHub CI/CD
- Railway OR Zeabur origins
- Docker/Supabase composition
- staging/production verification
- rollback/recovery
- bounded AI diagnosis/repair

Canonical instructions are in `SKILL.md`.

Never place real Cloudflare credentials in this package.
