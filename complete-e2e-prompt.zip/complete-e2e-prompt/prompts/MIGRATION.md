# Migration

Use MIGRATION mode.

Inventory source and destination, define responsibility ownership, preserve source data/configuration until destination verification, migrate through staging, verify data/artifacts/domains, use controlled cutover, maintain explicit rollback, and retire old infrastructure only after successful verification and authorization.
