# Existing Production

Use EXISTING_PRODUCTION mode.

Inventory GitHub, container registry, Supabase, selected runtime, Cloudflare, persistent data, variables, domains, deployment history, backups and rollback state before mutation.

Make minimal changes. Never recreate working infrastructure simply to simplify setup.
