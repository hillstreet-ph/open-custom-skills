# Master Prompt

Use `complete-e2e-prompt/SKILL.md` as the governing orchestration procedure.

Discover every applicable provider before mutation. Classify startup mode. Preserve existing production and data. Build a dependency graph and assign one provider owner per responsibility. Select Railway XOR Zeabur by default. Invoke specialized provider skills, validate staging, enforce production gates, promote a verified release, verify production end to end, then establish monitoring, backup, rollback, disaster recovery and maintenance.

Never fabricate credentials, duplicate infrastructure, weaken security, or claim unverified success.
