# Recovery

Use RECOVERY mode.

Identify last known-good source/artifact/configuration/data state. Restore dependencies in dependency order, preserve evidence, verify each layer, and do not overwrite production data blindly. Finish with full E2E verification and updated recovery documentation.
