# Fork Project

Use FORK startup mode.

Preserve upstream history/licenses/notices. Establish UPSTREAM and controlled ORIGIN. Use upstream-sync branches rather than merging upstream directly to main. Maintain fork customization documentation. Route upstream changes through compatibility review, CI/security, development, staging, E2E, release approval and production.
