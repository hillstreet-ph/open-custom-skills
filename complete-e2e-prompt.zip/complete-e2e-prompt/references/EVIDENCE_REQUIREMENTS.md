# Evidence Requirements

Never infer success.

GitHub: workflow/check/release evidence.
Docker: image/tag/digest evidence.
Supabase: migration/Auth/RLS/Storage test evidence.
Runtime: deployment/health/application evidence.
Cloudflare: DNS/TLS/route/origin evidence.

Only evidence-backed states may advance.
