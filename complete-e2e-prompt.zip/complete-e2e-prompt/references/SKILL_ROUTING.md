# Skill Routing

github-e2e-setup → source/fork/upstream/branches/CI/release
docker-e2e-setup → Dockerfile/build/registry/tag/digest/security
supabase-e2e-setup → DB/Auth/RLS/Storage/backend data lifecycle
railway-e2e-setup → Railway runtime
zeabur-e2e-setup → Zeabur runtime
cloudflare-e2e-setup → DNS/TLS/edge

Default runtime selection is Railway XOR Zeabur.
