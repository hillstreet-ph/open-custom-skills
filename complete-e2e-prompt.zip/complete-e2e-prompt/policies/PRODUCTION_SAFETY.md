# Production Safety

READ before WRITE. Preserve existing production. Before high-risk mutation: determine impact, verify recovery, define rollback, test staging, obtain appropriate authorization, apply minimal change, verify.
