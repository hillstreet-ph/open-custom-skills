# Data Loss Prevention

Treat DB, Storage and runtime volumes as independent data layers. Never drop/truncate/delete/restore blindly. Verify backup/recovery before destructive operations. Preserve source during migrations until destination verification.
