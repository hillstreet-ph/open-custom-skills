# Provider Ownership Policy

GitHub: source/governance/CI/release.
Docker Hub: OCI artifacts.
Supabase: DB/Auth/RLS/Storage/data services when selected.
Railway OR Zeabur: normal production runtime.
Cloudflare: DNS/TLS/edge.

One owner per responsibility. Railway XOR Zeabur by default.
