# Secrets

Never fabricate, print, commit, document, or bake secret values into images. Use provider secret stores and least privilege. Reports show names/owner/environment/status only.
