# AI Repair

Repair the owning layer only. Default maximum 3 automated repair cycles per failure: diagnose → patch → CI → staging → verify. Stop after limit and report blocker. Never weaken security to pass tests.
