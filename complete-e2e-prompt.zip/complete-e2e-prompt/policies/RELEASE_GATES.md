# Release Gates

Require applicable source, CI, security, migration, artifact, staging, Auth, RLS, Storage, backup, rollback and approval gates before production. Only PRODUCTION_VERIFIED is completion.
