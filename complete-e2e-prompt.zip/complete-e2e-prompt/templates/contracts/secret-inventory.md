# Secret Inventory

| Secret Name | Owner | Environment | Consumer | Status |
|---|---|---|---|---|

Never record secret values.
