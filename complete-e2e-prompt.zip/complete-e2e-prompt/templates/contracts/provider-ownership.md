# Provider Ownership Contract

GitHub:
Docker Hub:
Supabase:
Runtime Provider: RAILWAY | ZEABUR
Railway:
Zeabur:
Cloudflare:

Mark unused runtime provider NOT_REQUIRED.

For each responsibility record exactly one primary owner unless deliberate redundancy is documented.
