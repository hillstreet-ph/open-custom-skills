# Release Identity

Application Version:
Git SHA:
Docker Image:
Docker Digest:
Database Migration Version:
Runtime Provider:
Runtime Deployment:
Timestamp:
Verification Status:
Previous Known-Good Release:
