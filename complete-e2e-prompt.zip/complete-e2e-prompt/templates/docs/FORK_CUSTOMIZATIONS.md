# FORK CUSTOMIZATIONS

Populate from verified project/provider state only. Never include secret values or invent resource identifiers/status.
