# 01 DISCOVER / AUDIT

Read all applicable provider state, production dependencies, data and deployment history.
