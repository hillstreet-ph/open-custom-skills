# 04 SUPABASE

Invoke supabase-e2e-setup when required. Validate DB/migrations/Auth/RLS/Storage/backups.
