# 00 DETECT

Identify source/project and likely provider footprint. Do not mutate.
