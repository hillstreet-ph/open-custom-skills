# 07 CLOUDFLARE

Invoke cloudflare-e2e-setup. Validate origin before DNS/domain cutover and configure secure edge behavior.
