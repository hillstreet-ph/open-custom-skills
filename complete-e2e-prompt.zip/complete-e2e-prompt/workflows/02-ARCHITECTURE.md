# 02 ARCHITECTURE

Build dependency graph, assign provider ownership, select Railway XOR Zeabur by default, and calculate minimal changes.
