# 05 DOCKER

Invoke docker-e2e-setup when containerization is used. Build/security-test/publish immutable artifact and record digest.
