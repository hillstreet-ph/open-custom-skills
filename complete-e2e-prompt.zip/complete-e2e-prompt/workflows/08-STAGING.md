# 08 STAGING

Run applicable integration, Auth, RLS, Storage, runtime, worker, persistence, security and E2E validation.
