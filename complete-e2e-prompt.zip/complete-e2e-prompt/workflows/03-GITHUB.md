# 03 GITHUB

Invoke github-e2e-setup. Establish fork/upstream/branches/CI/security/release governance.
