# Credential Recovery
Recover configuration from provider resource inventory, secret-store inventory, environment contracts and authorized provider mechanisms. Do not assume one-time secret values can be retrieved. Do not regenerate solely for display.
