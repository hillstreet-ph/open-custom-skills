# Missing Credentials
For each missing credential, determine whether official authorized programmatic creation is available. If yes, create the real credential and store it directly in the correct secret store. If no, return PROVIDER_ACTION_REQUIRED. Never fabricate a substitute.
