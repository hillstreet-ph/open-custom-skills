# Existing Production
Inventory credential names, owners, scopes, consumers, environments and storage locations. Validate before replacement. Preserve working production credentials. Apply only minimal changes and never revoke first.
