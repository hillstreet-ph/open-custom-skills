# Master Prompt
Execute `credentials-e2e-setup/SKILL.md`.

Autonomously discover, validate, reuse, create when authorized, securely store, configure and test all credentials required by the selected application/infrastructure profile. Use real provider-issued values only. Never fabricate credentials, never unnecessarily revoke working credentials, never expose reusable secret values in reports, and return PROVIDER_ACTION_REQUIRED for unavoidable provider-enforced interactive actions.
