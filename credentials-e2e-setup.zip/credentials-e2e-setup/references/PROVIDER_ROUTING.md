# Provider Routing
GitHub → Actions/environment secrets and variables.
Docker Hub → scoped registry access tokens.
Supabase → client-safe config, privileged server secrets, DB/Auth/OAuth/Functions.
Zeabur → runtime/service secrets and private registry auth.
Cloudflare → scoped API tokens, Worker secrets, Pages variables/bindings.
Railway → only when selected profile includes Railway.
Other providers → discover official authorized mechanism before mutation.
