# Evidence Requirements
Credential existence is not verification. Evidence must show provider, consumer, intended operation, result classification, scope validation, status and timestamp without secret value.
