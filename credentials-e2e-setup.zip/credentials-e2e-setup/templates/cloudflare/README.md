# Cloudflare Credential Notes

Prefer scoped API tokens. Discover zone/account/bindings/secrets first and validate only required permissions.
