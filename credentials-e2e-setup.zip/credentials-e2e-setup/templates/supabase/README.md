# Supabase Credential Notes

Separate client-safe configuration from privileged server credentials. Never expose service/admin/DB secrets to frontend.
