# Other-Providers Credential Notes

Discover official provider credential mechanism and current resources before creation. Do not fabricate values or bypass security controls.
