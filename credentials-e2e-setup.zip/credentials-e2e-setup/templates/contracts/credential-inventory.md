# Credential Inventory
| Name | Provider | Type | Resource | Environment | Purpose | Consumer | Scope | Created/Reused | Status | Storage Location | Expiration | Last Validated | Retrieval/Rotation Location |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
Do not include reusable secret values.
