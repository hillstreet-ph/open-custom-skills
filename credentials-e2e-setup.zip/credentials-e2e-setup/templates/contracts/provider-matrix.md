# Provider Matrix
| Provider | Resource | Integration | Credential Type | Environment | Consumer | Storage | Validation | Status |
|---|---|---|---|---|---|---|---|---|
