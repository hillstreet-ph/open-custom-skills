# Credential Contract
| Name | Provider | Resource | Type | Environment | Owner | Consumers | Scope | Storage Location | Status |
|---|---|---|---|---|---|---|---|---|---|
Never record reusable secret values.
