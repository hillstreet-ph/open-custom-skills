# Zeabur Credential Notes

Configure secrets at correct project/environment/service. For private images, use authorized registry integration and validate deployment.
