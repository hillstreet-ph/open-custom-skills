# Github Credential Notes

Discover repo/environments/secret names/variables/workflow permissions first. Configure correct scope; never expose production secrets to untrusted PRs.
