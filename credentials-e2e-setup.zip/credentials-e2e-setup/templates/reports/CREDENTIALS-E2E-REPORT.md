# CREDENTIALS E2E REPORT

## Overall
STATUS:
APPLICATION:
ENVIRONMENT:
INTEGRATIONS DISCOVERED:
INTEGRATIONS VERIFIED:
BLOCKED:

## Credential Inventory
Use metadata only:
NAME:
PROVIDER:
TYPE:
RESOURCE:
ENVIRONMENT:
PURPOSE:
CONSUMER:
SCOPE:
CREATED_OR_REUSED:
STATUS:
STORAGE_LOCATION:
EXPIRATION:
LAST_VALIDATED:
RETRIEVAL_LOCATION:

## Provider Verification
GitHub:
Docker Hub:
Supabase:
Zeabur:
Cloudflare:
Railway if selected:
Other:

## Security
Secret Scan:
Frontend Exposure:
Repository Exposure:
Container Layer Exposure:
Log Exposure:
Least Privilege:
Duplicates:
Unnecessary Revocation:

## Missing / Blocked
Exact unresolved requirements only.

## Final Verification
Credential Inventory:
Secret Storage:
CI:
Runtime:
Database:
OAuth:
Webhooks:
Production Integration:

## Final Status
VERIFIED / PARTIALLY_VERIFIED / BLOCKED / FAILED
