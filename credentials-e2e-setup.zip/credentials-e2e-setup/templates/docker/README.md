# Docker Credential Notes

Prefer scoped registry access token over account password. Validate required push/pull access. Never bake credentials into images.
