# 09-SECURITY

Scan source/build/container/frontend/logs for exposure and verify least privilege.
