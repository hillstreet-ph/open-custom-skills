# 07-TEST

Test each credential/integration without exposing values.
