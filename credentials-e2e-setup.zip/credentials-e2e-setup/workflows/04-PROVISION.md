# 04-PROVISION

Create real provider-issued credentials when authorized/supported; securely generate application-owned secrets where required.
