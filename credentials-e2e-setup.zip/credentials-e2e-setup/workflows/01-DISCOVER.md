# 01-DISCOVER

Discover resources, credential names, variables, OAuth clients, service accounts and secret stores before mutation.
