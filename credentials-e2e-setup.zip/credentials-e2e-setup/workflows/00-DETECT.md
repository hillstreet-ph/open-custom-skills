# 00-DETECT

Detect application, selected infrastructure profile and connected providers.
