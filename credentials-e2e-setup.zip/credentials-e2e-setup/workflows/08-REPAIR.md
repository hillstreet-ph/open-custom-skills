# 08-REPAIR

Perform bounded diagnosis and minimal repair; avoid credential sprawl.
