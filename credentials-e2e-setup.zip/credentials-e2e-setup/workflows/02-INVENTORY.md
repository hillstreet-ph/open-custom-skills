# 02-INVENTORY

Build dependency graph and credential inventory; classify public/client-safe/secret/privileged.
