# Secret Handling
Never print, commit, document, log, bake into images or expose reusable secret values. Move secrets only through authorized secure channels into target secret stores.
