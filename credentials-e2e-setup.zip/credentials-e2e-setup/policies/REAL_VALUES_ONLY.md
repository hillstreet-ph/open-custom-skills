# Real Values Only
No fake/demo/example/dummy/changeme production credentials. Provider-issued credentials must come from official authorized mechanisms. Application-owned secrets may be securely generated only when specification expects them.
