# AI Repair
Maximum 3 automated repair cycles per integration failure. Diagnose owning layer first. Do not create credential sprawl or weaken security to pass validation.
