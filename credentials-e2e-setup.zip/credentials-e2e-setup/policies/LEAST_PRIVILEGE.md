# Least Privilege
Grant only required permissions and scopes. Prefer machine identities for automation and scoped provider tokens over broad account credentials.
