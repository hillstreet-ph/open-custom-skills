# Interactive Boundary
Do not bypass MFA, passkeys, CAPTCHA, OAuth consent, legal/billing approval or provider security controls. Return PROVIDER_ACTION_REQUIRED with the exact required action when automation cannot legitimately complete it.
