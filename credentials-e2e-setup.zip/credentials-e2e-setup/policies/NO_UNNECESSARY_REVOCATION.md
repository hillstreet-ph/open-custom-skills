# Preserve Existing Credentials
Setup is not authorization to revoke/rotate/delete credentials. Reuse valid credentials. Controlled rotation must create/store/configure/test replacement before old credential is revoked.
