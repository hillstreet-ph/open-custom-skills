# Rotation
When explicitly authorized: CREATE NEW → STORE → UPDATE CONSUMERS → TEST → VERIFY → CUT OVER → REVOKE OLD → VERIFY AGAIN. Never revoke first.
